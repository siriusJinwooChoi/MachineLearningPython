***********
Performance
***********

.. automodule:: numpy.doc.performance
