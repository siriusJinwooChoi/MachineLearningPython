.. _basics.subclassing:

*******************
Subclassing ndarray
*******************

.. automodule:: numpy.doc.subclassing
